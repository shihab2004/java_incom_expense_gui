package com.example.incomeexpense.model;

public enum EntryType {
    INCOME,
    EXPENSE
}
